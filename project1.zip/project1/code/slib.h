#if !defined(SGG_H)
/* ========================================================================
   $File: $
   $Date: $
   $Revision: $
   $Creator: Steven Grissom $

   A subset of my personal library file with custom type names, macros, and functions
   ======================================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef float r32;
typedef double r64;
typedef u32 b32;

//define static as different names for better grepability, depending on the context it is used in
#define internal static
#define persist static
#define global static

#if SLOW
// TODO(steven): Complete assertion macro
// this just causes a crash wherever the assertion fails so the debugger will show the location
#define Assert(x) if(!(x)) {*(volatile u32 *)0 = 0;}
#else
#define Assert(x)
#endif

#define InvalidCodePath Assert(!"InvalidCodePath")
#define InvalidDefaultCase default: {InvalidCodePath;} break

#define Kilobytes(value) ((value)*1024LL)
#define Megabytes(value) (Kilobytes(value)*1024LL)
#define Gigabytes(value) (Megabytes(value)*1024LL)
#define Terabytes(value) (Gigabytes(value)*1024LL)

#define ArrayCount(array) (sizeof(array) / sizeof((array)[0]))
#define Minimum(x,y) ((x) < (y) ? (x) : (y))
#define Maximum(x,y) ((x) > (y) ? (x) : (y))
// TODO(steven): swap. maybe xor swap?

#ifdef __cplusplus
}
#endif
    
#define SGG_H
#endif
