
nn1a: function one without noise
nn1b: function one with noise
nn2a: function two without noise
nn2b: function two with noise

the images are a graph of the output.
blue is matlab's calculated value for the given inputs
yellow is the test data values
green is the network output values

the images with a "pre" prefix are not the final graph. They are described in the report.

csvs are in the format, depending on the function.

input,output
input,output
input...

or

input,input,output
input,input,output
input...

